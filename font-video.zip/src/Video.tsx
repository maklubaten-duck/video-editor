import React, {useEffect, useState} from "react";
import {
  AbsoluteFill, Audio, Sequence, continueRender, delayRender,
  interpolate, staticFile, useCurrentFrame,
} from "remotion";
import {FONTS, FPS, LEAD, PROMO_START} from "./data";

// ---- Wordform brand (taken from the app's CSS) ----
const BG = "#f1f2f8", INK = "#0e1030", MUT = "#5b5e7e", LINE = "#d5d8ea";
const CARD = "#fff", ACC = "#3a2cff", TINT = "#e4e2ff", HI = "#ffd23f";
const UI = "Bricolage Grotesque";
const SH = "0 1px 2px rgba(14,16,48,.06),0 14px 30px -16px rgba(40,30,160,.28)";

// ---- font loading from Google Fonts (never fails the render) ----
const loadFont = (name: string, spec: string, sample: string) =>
  new Promise<void>((resolve) => {
    const done = () => resolve();
    const l = document.createElement("link");
    l.rel = "stylesheet";
    l.href = `https://fonts.googleapis.com/css2?family=${name.replace(/ /g, "+")}${spec}&display=block`;
    l.onload = () => {
      document.fonts.load(`${spec ? "800 " : ""}64px "${name}"`, sample + "Aa0123456789").then(done, done);
    };
    l.onerror = done;
    document.head.appendChild(l);
    setTimeout(done, 60000);
  });

const useFonts = () => {
  const [handle] = useState(() => delayRender("fonts", {timeoutInMilliseconds: 240000}));
  useEffect(() => {
    const jobs = [loadFont(UI, ":wght@400..800", "Wordform Your name, set in type.")];
    FONTS.forEach(([f, b]) => jobs.push(loadFont(f, "", f + b)));
    Promise.all(jobs).then(() => continueRender(handle));
  }, [handle]);
};

// ---- helpers ----
const cache: Record<string, number> = {};
const fit = (text: string, family: string, maxW: number, maxFs: number) => {
  const key = family + "|" + text + "|" + maxW + "|" + maxFs;
  if (cache[key]) return cache[key];
  const ctx = document.createElement("canvas").getContext("2d")!;
  ctx.font = `100px "${family}"`;
  const w = ctx.measureText(text).width || 1;
  return (cache[key] = Math.min(maxFs, (maxW / w) * 100));
};

const Mock: React.FC<{i: number; w: number; h: number; text?: string}> = ({i, w, h, text}) => {
  const [font, brand, color] = FONTS[i];
  const word = text ?? brand;
  const tile = h * 0.56;
  const fs = fit(word, font, w - tile - h * 0.9, h * 0.52);
  return (
    <div style={{
      width: w, height: h, background: CARD, border: `2px solid ${LINE}`, borderRadius: 32,
      boxShadow: SH, display: "flex", alignItems: "center", justifyContent: "center", gap: h * 0.16,
    }}>
      <div style={{
        width: tile, height: tile, borderRadius: tile * 0.28, background: color, color: "#fff",
        display: "grid", placeItems: "center", fontFamily: `"${font}"`, fontSize: tile * 0.6, lineHeight: 1,
      }}>{word[0]}</div>
      <div style={{fontFamily: `"${font}"`, fontSize: fs, color, lineHeight: 1.1, whiteSpace: "nowrap"}}>{word}</div>
    </div>
  );
};

// ---- scenes ----
const Hook: React.FC<{i: number}> = ({i}) => (
  <AbsoluteFill style={{alignItems: "center"}}>
    <div style={{
      marginTop: 130, width: 1560, textAlign: "center", fontFamily: `"${UI}"`, fontWeight: 800,
      fontSize: 128, lineHeight: 1, letterSpacing: "-0.04em", color: INK,
    }}>
      <span style={{color: ACC}}>50 FREE</span> Fonts That Look Amazing as Logos.
    </div>
    <div style={{position: "absolute", top: 650}}><Mock i={i} w={1200} h={290} /></div>
  </AbsoluteFill>
);

const FontFrame: React.FC<{i: number}> = ({i}) => {
  const font = FONTS[i][0];
  const fs = fit(font, font, 1680, 230);
  return (
    <AbsoluteFill>
      <div style={{
        position: "absolute", left: 110, top: 40, fontFamily: `"${UI}"`, fontWeight: 800,
        fontSize: 250, lineHeight: 1, letterSpacing: "-0.04em", color: INK,
      }}>{i + 1}</div>
      <div style={{
        position: "absolute", left: 0, right: 0, top: 330, height: 300, display: "flex",
        alignItems: "center", justifyContent: "center",
      }}>
        <div style={{fontFamily: `"${font}"`, fontSize: fs, color: INK, whiteSpace: "nowrap", lineHeight: 1.1}}>{font}</div>
      </div>
      <div style={{position: "absolute", left: 310, top: 720}}><Mock i={i} w={1300} h={270} /></div>
    </AbsoluteFill>
  );
};

// --- app promo (replica of the Wordform UI) ---
const Btn: React.FC<{children: React.ReactNode; p?: boolean; style?: React.CSSProperties}> = ({children, p, style}) => (
  <div style={{
    display: "inline-flex", alignItems: "center", justifyContent: "center", padding: "10px 16px",
    border: `1px solid ${p ? ACC : LINE}`, borderRadius: 12, background: p ? ACC : CARD,
    color: p ? "#fff" : INK, fontWeight: 600, fontSize: 16, whiteSpace: "nowrap", ...style,
  }}>{children}</div>
);

const Logo: React.FC = () => (
  <svg viewBox="0 0 32 32" width={34} height={34}>
    <rect width="32" height="32" rx="9" fill={ACC} />
    <path d="M7 10l3.5 12L16 12l5.5 10L25 10" fill="none" stroke="#fff" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" />
    <path d="M6 26h20" stroke={HI} strokeWidth="2.5" strokeLinecap="round" />
  </svg>
);

const Header: React.FC = () => (
  <div style={{height: 50, padding: "16px 20px 0", display: "flex", justifyContent: "space-between", alignItems: "center"}}>
    <div style={{display: "flex", alignItems: "center", gap: 10, fontWeight: 800, fontSize: 22, letterSpacing: "-0.03em"}}>
      <Logo />Wordform
    </div>
    <Btn style={{padding: 10}}>
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={INK} strokeWidth="2"><circle cx="12" cy="12" r="3" /><circle cx="12" cy="12" r="9" /></svg>
    </Btn>
  </div>
);

const GALLERY = [33, 48, 11, 43, 27, 25];

const Promo: React.FC<{p: number}> = ({p}) => {
  const cx = interpolate(p, [0, 1.6, 1.95, 2.0, 2.4, 4.4, 5.6], [900, 135, 135, 300, 300, 640, 640], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const cy = interpolate(p, [0, 1.6, 1.95, 2.0, 2.4, 4.4, 5.6], [560, 378, 378, 38, 38, 500, 500], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const press = p > 1.72 && p < 1.9;
  const typed = p < 2.6 ? "" : "Lumen".slice(0, Math.min(5, Math.floor((p - 2.6) / 0.15) + 1));
  const name = p < 2.6 ? "Nova" : typed;
  const hover = p > 4.3 ? 4 : -1;

  let body: React.ReactNode;
  if (p < 2.0) {
    const [hf, , hc] = FONTS[33];
    body = (
      <>
        <Header />
        <div style={{display: "grid", gridTemplateColumns: "1fr 617px", gap: 36, padding: "44px 20px 24px"}}>
          <div>
            <div style={{height: 124, fontWeight: 800, fontSize: 64, lineHeight: 0.96, letterSpacing: "-0.04em", marginBottom: 18}}>Your name, set in type.</div>
            <div style={{height: 90, fontSize: 19, lineHeight: 1.5, color: MUT, marginBottom: 24, maxWidth: 560}}>
              Type your brand name and see it in hundreds of distinct typefaces. Pick one, adjust it, and download your logo as SVG or PNG.
            </div>
            <Btn p style={{padding: "14px 22px", fontSize: 17, borderRadius: 14, transform: press ? "scale(0.96)" : "none"}}>Start with your name</Btn>
          </div>
          <div style={{
            position: "relative", width: 617, height: 354, background: CARD, border: `1px solid ${LINE}`, borderRadius: 24,
            boxShadow: SH, overflow: "hidden", display: "grid", placeItems: "center",
          }}>
            {[28, 72].map((t) => <div key={t} style={{position: "absolute", left: 0, right: 0, top: `${t}%`, height: 1, background: LINE}} />)}
            <div style={{position: "absolute", left: 0, right: 0, top: "50%", height: 1, background: ACC}} />
            <div style={{fontFamily: `"${hf}"`, fontSize: 130, color: hc, lineHeight: 1, position: "relative"}}>Nova</div>
          </div>
        </div>
        <div style={{display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 14, padding: "12px 20px", color: MUT}}>
          {[["Type", "your brand name"], ["Pick", "the typeface that fits"], ["Download", "SVG or PNG, fonts embedded"]].map(([b, t], k) => (
            <div key={b} style={{display: "flex", gap: 12, alignItems: "center"}}>
              <div style={{width: 30, height: 30, borderRadius: 15, background: HI, color: INK, fontWeight: 800, display: "grid", placeItems: "center"}}>{k + 1}</div>
              <span><b style={{color: INK}}>{b}</b> {t}</span>
            </div>
          ))}
        </div>
      </>
    );
  } else {
    const focus = p > 2.3;
    body = (
      <>
        <div style={{borderBottom: `1px solid ${LINE}`, borderTop: `1px solid ${LINE}`}}>
          <div style={{display: "flex", gap: 10, alignItems: "center", padding: "12px 20px 4px"}}>
            <div style={{
              flex: 1, height: 46, padding: "11px 14px", border: `1px solid ${focus ? ACC : LINE}`, borderRadius: 12,
              background: CARD, boxShadow: focus ? `0 0 0 3px ${TINT}` : "none", fontSize: 16, lineHeight: "22px",
            }}>{name}{focus && Math.floor(p * 3) % 2 === 0 ? "|" : ""}</div>
            <Btn style={{height: 46}}>Shuffle</Btn>
          </div>
          <div style={{display: "flex", gap: 8, padding: "8px 20px 12px"}}>
            {["All", "Display", "Serif", "Script", "Mono", "Pixel"].map((c, k) => (
              <div key={c} style={{
                padding: "6px 14px", borderRadius: 99, border: `1px solid ${k === 0 ? INK : LINE}`,
                background: k === 0 ? INK : CARD, color: k === 0 ? BG : INK, fontSize: 16,
              }}>{c}</div>
            ))}
          </div>
        </div>
        <div style={{display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16, padding: "22px 20px"}}>
          {GALLERY.map((fi, k) => {
            const [f, , c] = FONTS[fi];
            const h = k === hover;
            return (
              <div key={fi} style={{
                border: `1px solid ${h ? ACC : LINE}`, borderRadius: 18, background: CARD, overflow: "hidden",
                boxShadow: SH, transform: h ? "translateY(-2px)" : "none",
              }}>
                <div style={{height: 201, display: "grid", placeItems: "center", padding: 12}}>
                  <div style={{fontFamily: `"${f}"`, color: c, fontSize: fit(name || "Nova", f, 300, 76), lineHeight: 1.1, whiteSpace: "nowrap"}}>{name || "Nova"}</div>
                </div>
                <div style={{padding: "11px 14px", borderTop: `1px solid ${LINE}`, fontWeight: 700}}>{f}</div>
              </div>
            );
          })}
        </div>
      </>
    );
  }

  return (
    <AbsoluteFill>
      <div style={{width: 1280, height: 720, transform: "scale(1.5)", transformOrigin: "0 0", overflow: "hidden", position: "relative", background: BG, color: INK, fontFamily: `"${UI}"`}}>
        {body}
        <svg width="26" height="26" viewBox="0 0 24 24" style={{position: "absolute", left: cx, top: cy, transform: press ? "scale(0.85)" : "none"}}>
          <path d="M5 3l14 8-6 1.5L10 19z" fill="#111" stroke="#fff" strokeWidth="1.5" strokeLinejoin="round" />
        </svg>
      </div>
    </AbsoluteFill>
  );
};

// ---- main ----
const sfx = (from: number, vol: number) => (
  <Sequence key={from + "-" + vol} from={from} durationInFrames={10}>
    <Audio src={staticFile("slide.wav")} volume={vol} />
  </Sequence>
);

export const Video: React.FC = () => {
  useFonts();
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const firstStart = FONTS[0][3] - LEAD;

  let scene: React.ReactNode;
  if (t < firstStart) {
    scene = <Hook i={(Math.floor(t / 0.24) * 7 + 3) % 50} />;
  } else if (t >= PROMO_START) {
    scene = <Promo p={t - PROMO_START} />;
  } else {
    let i = 0;
    FONTS.forEach((f, k) => { if (t >= f[3] - LEAD) i = k; });
    scene = <FontFrame i={i} />;
  }

  const sounds: React.ReactNode[] = [];
  for (let k = 0; k * 0.24 < firstStart; k++) sounds.push(sfx(Math.round(k * 0.24 * FPS), 0.35));
  FONTS.forEach((f) => sounds.push(sfx(Math.round((f[3] - LEAD) * FPS), 0.8)));
  sounds.push(sfx(Math.round((PROMO_START + 1.75) * FPS), 0.6));
  sounds.push(sfx(Math.round((PROMO_START + 2.0) * FPS), 0.8));
  sounds.push(sfx(Math.round((PROMO_START + 2.3) * FPS), 0.5));

  return (
    <AbsoluteFill style={{background: BG}}>
      {scene}
      <Audio src={staticFile("voiceover.mp3")} />
      {sounds}
    </AbsoluteFill>
  );
};
