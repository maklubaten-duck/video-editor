import React from "react";
import {Composition} from "remotion";
import {Video} from "./Video";
import {FPS, TOTAL_SECONDS} from "./data";

export const Root: React.FC = () => (
  <Composition
    id="Main"
    component={Video}
    width={1920}
    height={1080}
    fps={FPS}
    durationInFrames={Math.round(TOTAL_SECONDS * FPS)}
  />
);
